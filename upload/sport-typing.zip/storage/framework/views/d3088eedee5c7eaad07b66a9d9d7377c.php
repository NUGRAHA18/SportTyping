

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Practice Typing</h2>
    <p>Select a text to practice your typing skills.</p>
    
    <div class="row mt-4">
        <!-- Category Filter -->
        <div class="col-md-3">
            <div class="card">
                <div class="card-header">
                    <h5>Categories</h5>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="<?php echo e(route('guest.practice')); ?>" class="list-group-item list-group-item-action <?php echo e(!request('category') ? 'active' : ''); ?>">
                            All Categories
                        </a>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('guest.practice', ['category' => $category->id])); ?>" class="list-group-item list-group-item-action <?php echo e(request('category') == $category->id ? 'active' : ''); ?>">
                                <?php echo e($category->name); ?> (<?php echo e($category->texts_count); ?>)
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Text List -->
        <div class="col-md-9">
            <div class="card">
                <div class="card-header">
                    <h5>Typing Texts</h5>
                </div>
                <div class="card-body">
                    <?php if($texts->count() > 0): ?>
                        <div class="list-group">
                            <?php $__currentLoopData = $texts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $text): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('guest.practice.show', $text)); ?>" class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1"><?php echo e($text->title); ?></h5>
                                        <small><?php echo e(ucfirst($text->difficulty_level)); ?></small>
                                    </div>
                                    <p class="mb-1"><?php echo e(Str::limit($text->content, 100)); ?></p>
                                    <small class="text-muted">Category: <?php echo e($text->category->name); ?></small>
                                </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="mt-3">
                            <?php echo e($texts->links()); ?>

                        </div>
                    <?php else: ?>
                        <p>No typing texts found.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sport-typing\resources\views/guest/practice.blade.php ENDPATH**/ ?>