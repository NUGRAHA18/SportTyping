

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Typing Lessons</h2>
    <p>Learn and improve your typing skills with structured lessons.</p>
    
    <div class="row mt-4">
        <?php if($lessons->count() > 0): ?>
            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 mb-4">
                    <div class="card h-100">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h5 class="mb-0"><?php echo e($lesson->title); ?></h5>
                            <span class="badge bg-<?php echo e($lesson->difficulty_level == 'beginner' ? 'success' : ($lesson->difficulty_level == 'intermediate' ? 'warning' : ($lesson->difficulty_level == 'advanced' ? 'danger' : 'primary'))); ?>">
                                <?php echo e(ucfirst($lesson->difficulty_level)); ?>

                            </span>
                        </div>
                        <div class="card-body">
                            <p><?php echo e(Str::limit($lesson->description ?? 'Learn typing techniques with this structured lesson.', 100)); ?></p>
                            <p class="text-muted">
                                <small>
                                    <i class="fas fa-clock"></i> Est. time: <?php echo e($lesson->estimated_completion_time ?? 10); ?> min
                                    <br>
                                    <i class="fas fa-star"></i> XP Reward: <?php echo e($lesson->experience_reward); ?>

                                </small>
                            </p>
                        </div>
                        <div class="card-footer">
                            <a href="<?php echo e(route('guest.lessons.show', $lesson)); ?>" class="btn btn-primary w-100">
                                Start Lesson
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-info">
                    No lessons available yet. Please check back later.
                </div>
            </div>
        <?php endif; ?>
    </div>

    <div class="mt-5 text-center">
        <p>Want to track your progress and earn badges?</p>
        <div>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary me-2">Login</a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Register</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sport-typing\resources\views/guest/lessons.blade.php ENDPATH**/ ?>