

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Typing Competitions</h2>
    <p>Challenge yourself and others in real-time typing competitions.</p>
    
    <div class="row mt-4">
        <!-- Active Competitions -->
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header bg-success text-white">
                    <h4 class="mb-0">Active Competitions</h4>
                </div>
                <div class="card-body">
                    <?php if($activeCompetitions->count() > 0): ?>
                        <div class="list-group">
                            <?php $__currentLoopData = $activeCompetitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1"><?php echo e($competition->title); ?></h5>
                                        <span class="badge bg-<?php echo e($competition->device_type == 'mobile' ? 'warning' : ($competition->device_type == 'pc' ? 'info' : 'success')); ?>">
                                            <?php echo e(ucfirst($competition->device_type)); ?>

                                        </span>
                                    </div>
                                    <p class="mb-1"><?php echo e($competition->description ?? 'Test your typing skills in this exciting competition!'); ?></p>
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <small class="text-muted">Started: <?php echo e($competition->start_time->diffForHumans()); ?></small>
                                        <a href="<?php echo e(route('guest.competition.show', $competition)); ?>" class="btn btn-primary btn-sm">
                                            Join Competition
                                        </a>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No active competitions right now. Check upcoming competitions or check back later.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Upcoming Competitions -->
        <div class="col-12">
            <div class="card">
                <div class="card-header bg-primary text-white">
                    <h4 class="mb-0">Upcoming Competitions</h4>
                </div>
                <div class="card-body">
                    <?php if($upcomingCompetitions->count() > 0): ?>
                        <div class="list-group">
                            <?php $__currentLoopData = $upcomingCompetitions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $competition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="list-group-item list-group-item-action">
                                    <div class="d-flex w-100 justify-content-between">
                                        <h5 class="mb-1"><?php echo e($competition->title); ?></h5>
                                        <span class="badge bg-<?php echo e($competition->device_type == 'mobile' ? 'warning' : ($competition->device_type == 'pc' ? 'info' : 'success')); ?>">
                                            <?php echo e(ucfirst($competition->device_type)); ?>

                                        </span>
                                    </div>
                                    <p class="mb-1"><?php echo e($competition->description ?? 'Test your typing skills in this exciting competition!'); ?></p>
                                    <div class="d-flex justify-content-between align-items-center mt-2">
                                        <small class="text-muted">Starts: <?php echo e($competition->start_time->diffForHumans()); ?></small>
                                        <span class="btn btn-outline-secondary btn-sm disabled">
                                            Coming Soon
                                        </span>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            No upcoming competitions scheduled. Check back later.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="mt-5 text-center">
        <p>Want to track your competition results and climb the leaderboards?</p>
        <div>
            <a href="<?php echo e(route('login')); ?>" class="btn btn-primary me-2">Login</a>
            <a href="<?php echo e(route('register')); ?>" class="btn btn-outline-primary">Register</a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\sport-typing\resources\views/guest/competitions.blade.php ENDPATH**/ ?>